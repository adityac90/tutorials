package com.adobe.carshare.cq.impl;

import com.adobe.carshare.cq.RestExchangeUtility;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Service;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Service
@Component(metatype = false)
public class RestExchangeUtilityImpl implements RestExchangeUtility {
    Logger log = LoggerFactory.getLogger(this.getClass());

    public String makeAGetCall(String url) {
        log.info("Inside makeAGetCall with URL -> {} ",url);
        try {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpGet getRequest = new HttpGet(url);
            getRequest.addHeader("accept", "application/json");
            HttpResponse response = httpClient.execute(getRequest);
            log.info("Inside makeAGetCall with response -> {} ",response.getStatusLine().getStatusCode());
            if (response.getStatusLine().getStatusCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatusLine().getStatusCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
            String output;
            String myJSON = "";
            while ((output = br.readLine()) != null) {
                //System.out.println(output);
                myJSON = myJSON + output;
            }
            httpClient.getConnectionManager().shutdown();
            return myJSON;
        } catch (Exception ex) {
            log.error("Exception  --> {}",ex.getMessage());
            return "";
        }


    }

    public int makeApostCall(String url, Object payLoad) {
        log.info("Inside make a Post call with URL - {}", url);
        log.info("Inside make a Post call with payload - {}", payLoad.toString());
        try {
            DefaultHttpClient httpClient = new DefaultHttpClient();
            HttpPost httpPost = new HttpPost(url);
            String json = new ObjectMapper().writeValueAsString(payLoad);
            StringEntity entity = new StringEntity(json);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            HttpResponse response = httpClient.execute(httpPost);
            log.info("Inside make a Post call status - {}", String.valueOf(response.getStatusLine().getStatusCode()));

            httpClient.getConnectionManager().shutdown();
            return response.getStatusLine().getStatusCode();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return 0;

    }
}
