package com.adobe.carshare.cq.services;

import com.adobe.carshare.cq.dao.LoginDao;

public class LoginServiceImpl implements LoginService {

    public String validateLogin(String email, String password) {
        LoginDao loginDao = new LoginDao();
        return loginDao.validateLogin(email,password);
    }
}
