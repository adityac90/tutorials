package com.adobe.carshare.cq.services;

import com.adobe.carshare.cq.dao.UserRegistrationDao;
import com.adobe.carshare.cq.dtos.Users;

public class UserRegistrationServiceImpl implements UserRegistrationService {

    public String reserveUser(Users user) {
        UserRegistrationDao userRegistrationDao = new UserRegistrationDao();
        return userRegistrationDao.reserveUser(user);
    }
}
