package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.dtos.Users;
import com.adobe.carshare.cq.services.UserRegistrationService;
import com.adobe.carshare.cq.services.UserRegistrationServiceImpl;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@SlingServlet(paths = "/bin/makeAReservation")
public class UserRegistrationServlet extends SlingAllMethodsServlet {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    protected void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
       log.info("Inside doPost of UserRegistrationServlet");
        String fullName = request.getParameter("fullName");
        String email = request.getParameter("email");
        Date dateOfBirth =null;
        try {
             dateOfBirth = new SimpleDateFormat("yyyy-mm-dd").parse(request.getParameter("dateOfBirth"));
        } catch (ParseException e) {
            dateOfBirth = new Date();
            e.printStackTrace();
        }
        String password = request.getParameter("password");
        String driverLicense = request.getParameter("driverLicense");

        Users user = new Users(fullName,email,dateOfBirth,password,driverLicense);
        UserRegistrationService userRegistrationService = new UserRegistrationServiceImpl();
        log.info("Before Calling Service lAyer data -- {}",user.toString());
        String responseFromService = userRegistrationService.reserveUser(user);
        response.getWriter().println(responseFromService);

    }
}
