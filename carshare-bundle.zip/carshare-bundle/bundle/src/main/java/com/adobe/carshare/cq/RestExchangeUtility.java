package com.adobe.carshare.cq;

import java.io.IOException;

public interface RestExchangeUtility {
    public String makeAGetCall(String url);
    public int makeApostCall(String url, Object payLoad ) throws IOException;
}
