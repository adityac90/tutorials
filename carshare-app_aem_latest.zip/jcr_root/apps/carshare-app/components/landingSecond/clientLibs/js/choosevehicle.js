$(document).ready(function(){

    alert("Choose Vehicle");

});
