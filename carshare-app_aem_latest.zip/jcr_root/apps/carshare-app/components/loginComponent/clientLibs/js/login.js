$(document).ready(function(){
    
    $("#login_btn").click(function(e){
        e.preventDefault();
        var data =$("#loginForm").serialize();
       // alert(data);
        $.ajax({
            type: "GET",
            url: "/bin/validateLogin",
            data: data,
            success: function(msg){
                var responseMsg = msg;
                if(responseMsg.includes("{")){
                    window.location.href = "http://localhost:4502/content/carshare-app/registrationlanding.html";
                }
                else{
					window.location.href = "http://localhost:4502/content/carshare-app.html?errMsg=Invalid Credentials"; 

                }


            },
            error:function(errMsg){
				alert("error!! Login failed ->"+errMsg);
            }
            
        }); 
        
        
        
    });
    
    $("#signup_btn").click(function(e){
        
        e.preventDefault();
        
        window.location.href = "http://localhost:4502/content/carshare-app/registration.html"; 
        
    });
    
    $("#reserve_btn").click(function(e){
        e.preventDefault();
        var data =$("#regForm").serialize();
        $.ajax({
            type: "POST",
            url: "/bin/makeAReservation",
            data: data,
            success: function(msg){
			 window.location.href = "http://localhost:4502/content/carshare-app.html?message=Registration Successful.Login with Credentials";  
            },
            error:function(errMsg){
				alert("error!! Registration failed");
            }
            
        });    
        

        
        
    });
    
    
});
