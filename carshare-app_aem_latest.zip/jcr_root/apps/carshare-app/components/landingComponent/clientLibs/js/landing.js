$(document).ready(function(){
    var locationDropDownObj;

        $.ajax({
            type: "GET",
            url: "http://localhost:8080/getAllLocations",
            success: function(value){
				locationDropDownObj = value;
                $.each(locationDropDownObj, function (i, item) {
                    //dropLocation
					$("#pickUpLocation").append("<option value='"+item.locationCode+"~"+item.locationName+"~"+item.locationDesc+"'>" + item.locationName + "</option>");
                    $("#dropLocation").append("<option value='"+item.locationCode+"~"+item.locationName+"~"+item.locationDesc+"'>" + item.locationName + "</option>");

                });

            }

        }); 


   /* $("#cnt1").click(function(e){
        alert("zz Goint to Choose Vehicle 22");
		e.preventDefault();
       var data = $("#reservationDetails1").serialize();
        alert("yyy->"+data);
        $.ajax({
            type: "GET",
            url: "/bin/savePageOne",
            data:data,
            success: function(value){
            }

        }); 


    });*/
    

});
