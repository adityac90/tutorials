package org.carshare.restapi.services.modell;

import javax.persistence.*;

@Entity
public class RatePlan {
    @Id
    private long rateId;
    private String rateCode;
    private String ratePlanName;
    private String currency;
    private long hourlyRate;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "location_code")
    private Location location;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "vehicle_code")
    private Vehicle vehicle;

    public RatePlan() {
    }

    public long getRateId() {
        return rateId;
    }

    public void setRateId(long rateId) {
        this.rateId = rateId;
    }

    public String getRateCode() {
        return rateCode;
    }

    public void setRateCode(String rateCode) {
        this.rateCode = rateCode;
    }

    public String getRatePlanName() {
        return ratePlanName;
    }

    public void setRatePlanName(String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public long getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(long hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
}
