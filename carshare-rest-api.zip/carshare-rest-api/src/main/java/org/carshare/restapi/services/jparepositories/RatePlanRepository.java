package org.carshare.restapi.services.jparepositories;

import org.carshare.restapi.services.modell.RatePlan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RatePlanRepository  extends JpaRepository<RatePlan,Long> {
    List<RatePlan> findByLocation_LocationCodeAndVehicle_VehicleCode(String locationCode,String vehicleCode);
}
